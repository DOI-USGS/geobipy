
def test_statarray():




if __name__ == "__main__":

    test_statarray()